<?php
	echo "Hello World!";
	echo "id=".$_GET["id"];
	echo "name=".$_GET["name"];
	phpinfo();
?>