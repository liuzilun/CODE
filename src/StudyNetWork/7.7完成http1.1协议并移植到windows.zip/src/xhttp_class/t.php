<?php
echo $_GET["id"];
?>
