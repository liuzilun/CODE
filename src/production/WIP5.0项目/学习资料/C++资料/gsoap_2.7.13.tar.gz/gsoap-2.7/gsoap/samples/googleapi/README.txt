Google API Web service example client application.

The Google API service provides a SOAP interface to the Google search engine.

The Google API SOAP server requires typed messages (xsi:type). The soapcpp2
option -t is used to generate the necessary type-enabled serializers.

Google discontinued the distribution of keys for their API service.
