
The 'extras' directory contains useful additions.

All contributions are covered by the gSOAP public license, unless specifically
stated otherwise in the source. The following authors provided the
contributions included in this directory:

ckdb.h ckdb.c			Simple Cookie database manager (store/load)
ckdbtest.h ckdbtest.c		Test code for Simple Cookie database manager
fault.cpp			Print SOAP Fault messages to C++ streams
logging.cpp			Log send, receive, and trace messages on streams
soapdefs.h			To enable logging

fault.cpp contributed by A. Kelly
logging.cpp contributed by M. Helmick
